function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);     
}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);     
}
function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(0, 0, 50);
}
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;

function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha = xBolinha + 1;
}


let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

function setup() {
    createCanvas(600, 400);
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;
}
function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha += velocidadeXBolinha;
    //yBolinha += velocidadeYBolinha;
    
    if (xBolinha > width) {
        velocidadeXBolinha *= -1;
    }function setup() {
2
  createCanvas(400, 400);
3
}
4
​
5
function draw() {
6
  background(220);     
7
}
8
function setup() {
9
  createCanvas(400, 400);
10
}
11
​
12
function draw() {
13
  background(0);     
14
}
15
function setup() {
16
    createCanvas(600, 400);
17
}
18
​
19
function draw() {
20
    background(0);
21
    circle(0, 0, 50);
22
}
23
let xBolinha = 300;
24
let yBolinha = 200;
25
let diametro = 15;
26
​
27
function setup() {
28
    createCanvas(600, 400);
29
}
30
​
31
function draw() {
32
    background(0);
33
    circle(xBolinha, yBolinha, diametro);
34
}
35
​
36
function draw() {
37
    background(0);
38
    circle(xBolinha, yBolinha, diametro);
39
    xBolinha = xBolinha + 1;
40
}
41
​
42
​
43
let velocidadeXBolinha = 6;
44
let velocidadeYBolinha = 6;
45
​
46
function setup() {
47
    createCanvas(600, 400);
48
}
49
​
50
function draw() {
51
    background(0);
52
    circle(xBolinha, yBolinha, diametro);
53
    xBolinha += velocidadeXBolinha;
54
    yBolinha += velocidadeYBolinha;
55
}
56
function draw() {
57
    background(0);
58
    circle(xBolinha, yBolinha, diametro);
59
    xBolinha += velocidadeXBolinha;
60
    //yBolinha += velocidadeYBolinha;
61
    
}
function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha += velocidadeXBolinha;
    //yBolinha += velocidadeYBolinha;
    
   if (xBolinha > width || xBolinha < 0) {
    velocidadeXBolinha *= -1;
     
Password is stron

Make sure it's at least 15 characters OR at least 8 characters including a number and a lowercase letter.

 }
}
function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    //xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;
    
  function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha += velocidadeXBolinha;
    //yBolinha += velocidadeYBolinha;
    
   if (xBolinha > width || xBolinha < 0) {
    velocidadeXBolinha *= -1;
    }
}
function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    //xBolinha += velocidadeXBolinha;
    yBolinha += velocidadeYBolinha;
    
    if (xBolinha > width || xBolinha < 0) {
        velocidadeXBolinha *= -1;
    }
    if (yBolinha > height || yBolinha < 0) {
        velocidadeYBolinha *= -1;
    }
}

function draw() {
    background(0);
    circle(xBolinha, yBolinha, diametro);
    xBolinha += velocidadeXBolinha;
    //yBolinha += velocidadeYBolinha;
    
   if (xBolinha > width || xBolinha < 0) {
    velocidadeXBolinha *= -1;
    }
